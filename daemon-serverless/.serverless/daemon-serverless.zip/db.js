module.exports =  {
    database: 'postgres',
    host: 'daemon-db.caylqwlmlyc5.us-east-2.rds.amazonaws.com',
    port: '5432',
    user: 'root_daemon',
    password: 'root2020',
  }
  